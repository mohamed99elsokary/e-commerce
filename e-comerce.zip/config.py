from imports import app

app.config["MYSQL_USER"] = "joker171joker72"
app.config["MYSQL_PASSWORD"] = "J!171?joker"
app.config["MYSQL_HOST"] = "joker171joker72.mysql.pythonanywhere-services.com"
app.config["MYSQL_DB"] = "joker171joker72$mundo"
app.config["MYSQL_CURSORCLASS"] = "DictCursor"
