successful = 1000
email_taken = 1001
wrong_password = 1002
edit_faild = 1003
reset_password_faild = 1004